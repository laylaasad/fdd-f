import React from 'react';

export default function PrivacyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-heading font-bold text-secondary-900 mb-8">سياسة الخصوصية</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6 sm:p-8 space-y-8">
        <section>
          <h2 className="text-2xl font-heading font-bold text-secondary-800 mb-4">جمع المعلومات</h2>
          <p className="text-secondary-600 leading-relaxed">
            نحن نجمع المعلومات التي تقدمها لنا عند استخدام موقعنا، مثل عنوان البريد الإلكتروني والاسم عند الاشتراك في النشرة البريدية أو إرسال رسالة عبر نموذج الاتصال.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-heading font-bold text-secondary-800 mb-4">استخدام المعلومات</h2>
          <p className="text-secondary-600 leading-relaxed mb-4">
            نستخدم المعلومات التي نجمعها للأغراض التالية:
          </p>
          <ul className="list-disc list-inside space-y-2 text-secondary-600">
            <li>تقديم وتحسين خدماتنا</li>
            <li>التواصل معك بخصوص استفساراتك</li>
            <li>إرسال النشرات الإخبارية والتحديثات</li>
            <li>تحليل وتحسين أداء الموقع</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-heading font-bold text-secondary-800 mb-4">حماية المعلومات</h2>
          <p className="text-secondary-600 leading-relaxed">
            نحن نتخذ إجراءات أمنية مناسبة لحماية معلوماتك الشخصية من الوصول غير المصرح به أو التعديل أو الإفصاح أو الإتلاف.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-heading font-bold text-secondary-800 mb-4">ملفات تعريف الارتباط</h2>
          <p className="text-secondary-600 leading-relaxed">
            نستخدم ملفات تعريف الارتباط لتحسين تجربة المستخدم وجمع البيانات الإحصائية حول حركة المرور وكيفية استخدام موقعنا.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-heading font-bold text-secondary-800 mb-4">التعديلات على سياسة الخصوصية</h2>
          <p className="text-secondary-600 leading-relaxed">
            نحتفظ بالحق في تحديث سياسة الخصوصية هذه في أي وقت. سيتم نشر أي تغييرات على هذه الصفحة وسيتم إخطار المستخدمين بالتغييرات المهمة.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-heading font-bold text-secondary-800 mb-4">اتصل بنا</h2>
          <p className="text-secondary-600 leading-relaxed">
            إذا كان لديك أي أسئلة حول سياسة الخصوصية الخاصة بنا، يرجى الاتصال بنا عبر صفحة الاتصال أو إرسال بريد إلكتروني إلى info@example.com.
          </p>
        </section>
      </div>
    </div>
  );
}