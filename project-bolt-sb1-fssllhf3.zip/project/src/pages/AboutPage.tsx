import React from 'react';

export default function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-heading font-bold text-secondary-900 mb-8">من نحن</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6 sm:p-8 space-y-6">
        <section>
          <h2 className="text-2xl font-heading font-bold text-secondary-800 mb-4">مهمتنا</h2>
          <p className="text-secondary-600 leading-relaxed">
            نسعى إلى تقديم محتوى عربي عالي الجودة يثري المعرفة ويساهم في تطوير المجتمع العربي. نؤمن بأن المعرفة حق للجميع، ونعمل على توفير مصادر موثوقة ومفيدة لقرائنا.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-heading font-bold text-secondary-800 mb-4">رؤيتنا</h2>
          <p className="text-secondary-600 leading-relaxed">
            نطمح أن نكون المنصة الرائدة في تقديم المحتوى العربي الهادف والمفيد، ونسعى لبناء مجتمع معرفي يساهم في تطوير وتنمية المنطقة العربية.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-heading font-bold text-secondary-800 mb-4">قيمنا</h2>
          <ul className="list-disc list-inside space-y-3 text-secondary-600">
            <li>الجودة والمصداقية في المحتوى المقدم</li>
            <li>الشفافية والوضوح في التعامل</li>
            <li>الابتكار والتطوير المستمر</li>
            <li>احترام خصوصية المستخدمين</li>
            <li>المسؤولية المجتمعية</li>
          </ul>
        </section>
      </div>
    </div>
  );
}