import React, { useState, useEffect, useRef } from 'react';
import { Search, Send, ChevronLeft, ArrowRight, TrendingUp, Clock, Mail, Bell } from 'lucide-react';
import { useTranslation } from 'react-i18next';

function HomePage() {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const mainRef = useRef<HTMLElement>(null);

  // Mouse parallax effect
  const handleMouseMove = (e: React.MouseEvent<HTMLElement>) => {
    const { clientX, clientY } = e;
    const { innerWidth, innerHeight } = window;
    
    const moveX = (clientX - innerWidth / 2) / innerWidth * 20;
    const moveY = (clientY - innerHeight / 2) / innerHeight * 20;

    const elements = document.querySelectorAll('.mouse-parallax');
    elements.forEach((el) => {
      (el as HTMLElement).style.transform = `translate(${moveX}px, ${moveY}px)`;
    });
  };

  // Scroll animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      {
        threshold: 0.1,
      }
    );

    document.querySelectorAll('.fade-up').forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Newsletter subscription:', email);
    setIsSubscribed(true);
    setTimeout(() => {
      setIsSubscribed(false);
      setEmail('');
    }, 3000);
  };

  const latestArticles = [
    { 
      id: 1, 
      titleKey: 'homepage.articles.productivity.title',
      dateKey: 'homepage.dates.march15',
      excerptKey: 'homepage.articles.productivity.excerpt',
      image: 'https://source.unsplash.com/random/800x400?productivity',
      readTime: '5',
      categoryKey: 'homepage.articles.productivity.category'
    },
    { 
      id: 2, 
      titleKey: 'homepage.articles.business.title',
      dateKey: 'homepage.dates.march12',
      excerptKey: 'homepage.articles.business.excerpt',
      image: 'https://source.unsplash.com/random/800x400?business',
      readTime: '8',
      categoryKey: 'homepage.articles.business.category'
    },
    { 
      id: 3, 
      titleKey: 'homepage.articles.marketing.title',
      dateKey: 'homepage.dates.march10',
      excerptKey: 'homepage.articles.marketing.excerpt',
      image: 'https://source.unsplash.com/random/800x400?marketing',
      readTime: '10',
      categoryKey: 'homepage.articles.marketing.category'
    }
  ];

  const featuredPosts = [
    {
      id: 4,
      titleKey: 'homepage.articles.remote.title',
      dateKey: 'homepage.dates.march8',
      excerptKey: 'homepage.articles.remote.excerpt',
      image: 'https://source.unsplash.com/random/800x400?remote-work',
      readTime: '7',
      categoryKey: 'homepage.articles.remote.category'
    },
    {
      id: 5,
      titleKey: 'homepage.articles.sustainable.title',
      dateKey: 'homepage.dates.march5',
      excerptKey: 'homepage.articles.sustainable.excerpt',
      image: 'https://source.unsplash.com/random/800x400?sustainable',
      readTime: '6',
      categoryKey: 'homepage.articles.sustainable.category'
    },
    {
      id: 6,
      titleKey: 'homepage.articles.mental.title',
      dateKey: 'homepage.dates.march3',
      excerptKey: 'homepage.articles.mental.excerpt',
      image: 'https://source.unsplash.com/random/800x400?wellness',
      readTime: '9',
      categoryKey: 'homepage.articles.mental.category'
    }
  ];

  return (
    <div 
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12"
      onMouseMove={handleMouseMove}
    >
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Main Content */}
        <main ref={mainRef} className="flex-1 min-w-0">
          {/* Featured Posts Section */}
          <section className="mb-12">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8">
              <h2 className="text-3xl sm:text-4xl font-heading font-extrabold text-secondary-900 tracking-tight mb-4 sm:mb-0 fade-up">
                <span className="text-primary-600">{t('homepage.featured.title')}</span>
              </h2>
              <a href="#" className="group inline-flex items-center px-4 py-2 rounded-lg text-primary-600 hover:bg-primary-50 transition-all duration-200 fade-up">
                <span className="font-medium">{t('homepage.featured.viewAll')}</span>
                <ArrowRight size={16} className="ml-1 transform group-hover:translate-x-1 transition-transform duration-200" />
              </a>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {featuredPosts.map((post, index) => (
                <article 
                  key={post.id} 
                  className="bg-white rounded-xl shadow-md overflow-hidden card-hover fade-up"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="relative overflow-hidden">
                    <img
                      src={post.image}
                      alt={t(post.titleKey)}
                      className="w-full h-48 sm:h-56 object-cover image-hover"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <span className="absolute top-4 left-4 px-3 py-1 bg-primary-600 text-white text-sm font-medium rounded-full mouse-parallax">
                      {t(post.categoryKey)}
                    </span>
                  </div>
                  <div className="p-4 sm:p-6">
                    <div className="flex items-center space-x-4 mb-3">
                      <p className="text-sm text-primary-600 font-medium flex items-center">
                        <Clock size={14} className="mr-1" />
                        {post.readTime} {t('homepage.readTime.min')}
                      </p>
                      <p className="text-sm text-secondary-500">{t(post.dateKey)}</p>
                    </div>
                    <h3 className="text-xl sm:text-2xl font-heading font-bold text-secondary-900 mb-3 group-hover:text-primary-600 transition-colors duration-200 line-clamp-2">
                      {t(post.titleKey)}
                    </h3>
                    <p className="text-secondary-600 mb-4 line-clamp-2 leading-relaxed text-sm sm:text-base">
                      {t(post.excerptKey)}
                    </p>
                    <button className="inline-flex items-center px-4 py-2 bg-primary-50 text-primary-600 rounded-lg font-semibold hover:bg-primary-100 transition-all duration-200 group-hover:translate-x-1 transform text-sm sm:text-base">
                      {t('homepage.readArticle')}
                      <ArrowRight size={18} className="ml-1" />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </section>

          {/* Latest Posts Section */}
          <section>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8">
              <h2 className="text-3xl sm:text-4xl font-heading font-extrabold text-secondary-900 tracking-tight mb-4 sm:mb-0">
                <span className="text-primary-600">{t('homepage.latest.title')}</span>
              </h2>
              <a href="#" className="group inline-flex items-center px-4 py-2 rounded-lg text-primary-600 hover:bg-primary-50 transition-all duration-200">
                <span className="font-medium">{t('homepage.latest.browseArchive')}</span>
                <ArrowRight size={16} className="ml-1 transform group-hover:translate-x-1 transition-transform duration-200" />
              </a>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {latestArticles.map((post) => (
                <article 
                  key={post.id} 
                  className="bg-white rounded-xl shadow-md overflow-hidden transform hover:scale-[1.02] transition-all duration-300 group"
                >
                  <div className="relative">
                    <img
                      src={post.image}
                      alt={t(post.titleKey)}
                      className="w-full h-48 sm:h-56 object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <span className="absolute top-4 left-4 px-3 py-1 bg-primary-600 text-white text-sm font-medium rounded-full">
                      {t(post.categoryKey)}
                    </span>
                  </div>
                  <div className="p-4 sm:p-6">
                    <div className="flex items-center space-x-4 mb-3">
                      <p className="text-sm text-primary-600 font-medium flex items-center">
                        <Clock size={14} className="mr-1" />
                        {post.readTime} {t('homepage.readTime.min')}
                      </p>
                      <p className="text-sm text-secondary-500">{t(post.dateKey)}</p>
                    </div>
                    <h3 className="text-xl sm:text-2xl font-heading font-bold text-secondary-900 mb-3 group-hover:text-primary-600 transition-colors duration-200 line-clamp-2">
                      {t(post.titleKey)}
                    </h3>
                    <p className="text-secondary-600 mb-4 line-clamp-2 leading-relaxed text-sm sm:text-base">
                      {t(post.excerptKey)}
                    </p>
                    <button className="inline-flex items-center px-4 py-2 bg-primary-50 text-primary-600 rounded-lg font-semibold hover:bg-primary-100 transition-all duration-200 group-hover:translate-x-1 transform text-sm sm:text-base">
                      {t('homepage.readArticle')}
                      <ArrowRight size={18} className="ml-1" />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </section>
        </main>

        {/* Sidebar */}
        <aside className="lg:w-80 lg:flex-shrink-0">
          {/* Newsletter Subscription */}
          <div className="gradient-animate rounded-xl shadow-lg p-6 mb-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-16 -translate-y-16">
              <div className="absolute inset-0 bg-white opacity-10 rounded-full"></div>
            </div>
            <div className="relative">
              <div className="flex items-center mb-2">
                <Mail size={24} className="text-white mr-2 mouse-parallax" />
                <h3 className="text-xl sm:text-2xl font-heading font-bold text-white">
                  {t('homepage.newsletter.title')}
                </h3>
              </div>
              <p className="text-primary-100 mb-6 text-sm sm:text-base">
                {t('homepage.newsletter.description')}
              </p>
              <form onSubmit={handleNewsletterSubmit} className="space-y-4">
                <div className="relative">
                  <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border-2 border-primary-400 bg-white/10 text-white placeholder-primary-200 focus:outline-none focus:border-white transition-colors duration-200"
                    placeholder={t('homepage.newsletter.placeholder')}
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-white text-primary-600 px-4 py-3 rounded-lg font-semibold hover:bg-primary-50 transform hover:-translate-y-0.5 transition-all duration-200 flex items-center justify-center"
                >
                  <Bell size={18} className="mr-2" />
                  {t('homepage.newsletter.button')}
                </button>
              </form>
              {isSubscribed && (
                <div className="absolute bottom-0 left-0 right-0 bg-green-500 text-white text-center py-2 transform translate-y-full animate-slide-up">
                  {t('homepage.newsletter.success')}
                </div>
              )}
            </div>
          </div>

          {/* Trending Posts */}
          <div className="bg-white rounded-xl shadow-md p-6 fade-up">
            <div className="flex items-center mb-6">
              <TrendingUp size={24} className="text-primary-600 mr-2" />
              <h3 className="text-xl sm:text-2xl font-heading font-bold text-secondary-900">
                {t('homepage.trending.title')}
              </h3>
            </div>
            <div className="space-y-6">
              {latestArticles.map((article) => (
                <a
                  key={article.id}
                  href="#"
                  className="block group"
                >
                  <div className="flex items-start space-x-4">
                    <img
                      src={article.image}
                      alt={t(article.titleKey)}
                      className="w-20 h-20 rounded-lg object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                    <div className="flex-1 min-w-0">
                      <span className="inline-block px-2 py-1 bg-primary-50 text-primary-600 text-xs font-medium rounded-full mb-2">
                        {t(article.categoryKey)}
                      </span>
                      <h4 className="text-base sm:text-lg font-semibold text-secondary-900 group-hover:text-primary-600 transition-colors duration-200 line-clamp-2">
                        {t(article.titleKey)}
                      </h4>
                      <div className="flex items-center mt-2">
                        <Clock size={14} className="text-secondary-400 mr-1" />
                        <p className="text-sm text-secondary-500">{article.readTime} {t('homepage.readTime.min')}</p>
                      </div>
                    </div>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

export default HomePage;