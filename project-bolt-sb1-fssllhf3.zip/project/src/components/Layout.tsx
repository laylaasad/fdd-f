import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, Home, BookOpen, Mail, Menu, X, Info, Phone, MapPin, Globe } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLanguageMenuOpen, setIsLanguageMenuOpen] = useState(false);
  const location = useLocation();
  const { t, i18n } = useTranslation();

  const languages = [
    { code: 'en', name: 'English', flag: '🇬🇧' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'zh', name: '中文', flag: '🇨🇳' }
  ];

  const [currentLanguage, setCurrentLanguage] = useState(
    languages.find(lang => lang.code === i18n.language) || languages[0]
  );

  const handleLanguageChange = (language: typeof languages[0]) => {
    setCurrentLanguage(language);
    i18n.changeLanguage(language.code);
    setIsLanguageMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-secondary-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center h-16 px-4 sm:px-6 lg:px-8 relative">
            <div className="flex items-center">
              <button
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="p-2 rounded-md text-secondary-600 hover:text-primary-700 hover:bg-secondary-50 transition-colors duration-200 lg:hidden"
                aria-label={t('header.menu')}
              >
                <Menu size={24} />
              </button>
              <Link to="/" className="flex items-center ml-2 sm:ml-4">
                <BookOpen className="h-8 w-8 text-primary-600" />
                <h1 className="text-2xl sm:text-3xl font-heading font-bold text-primary-900 tracking-tight ml-2">My Blog</h1>
              </Link>
            </div>
            
            {/* Search Bar */}
            <div className="hidden md:block flex-1 max-w-lg mx-4">
              <div className="relative">
                <input
                  type="text"
                  className="w-full px-4 py-2 pl-10 rounded-lg border border-secondary-200 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-base bg-white placeholder-secondary-400"
                  placeholder={t('header.search')}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-secondary-400" size={20} />
              </div>
            </div>

            {/* Language Switcher */}
            <div className="hidden md:block relative">
              <button
                onClick={() => setIsLanguageMenuOpen(!isLanguageMenuOpen)}
                className="flex items-center space-x-2 px-3 py-2 rounded-lg text-secondary-700 hover:bg-secondary-50 transition-colors duration-200"
              >
                <Globe className="h-5 w-5" />
                <span className="text-sm font-medium">{currentLanguage.flag} {currentLanguage.name}</span>
              </button>

              {isLanguageMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                  <div className="py-1" role="menu" aria-orientation="vertical">
                    {languages.map((language) => (
                      <button
                        key={language.code}
                        onClick={() => handleLanguageChange(language)}
                        className={`${
                          currentLanguage.code === language.code
                            ? 'bg-primary-50 text-primary-700'
                            : 'text-secondary-700 hover:bg-secondary-50'
                        } group flex items-center w-full px-4 py-2 text-sm transition-colors duration-200`}
                        role="menuitem"
                      >
                        <span className="mr-2">{language.flag}</span>
                        {language.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Mobile menu button */}
            <button
              className="md:hidden p-2 rounded-md text-secondary-600 hover:text-primary-700 hover:bg-secondary-50 transition-colors duration-200"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label={t('header.menu')}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden absolute w-full bg-white border-b border-secondary-200 shadow-lg">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <div className="px-3 py-2">
                <div className="relative">
                  <input
                    type="text"
                    className="w-full px-4 py-2 pl-10 rounded-lg border border-secondary-200 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-base bg-white placeholder-secondary-400"
                    placeholder={t('header.search')}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-secondary-400" size={20} />
                </div>
              </div>
              {/* Language Switcher for Mobile */}
              <div className="px-3 py-2">
                <div className="flex flex-col space-y-2">
                  {languages.map((language) => (
                    <button
                      key={language.code}
                      onClick={() => handleLanguageChange(language)}
                      className={`${
                        currentLanguage.code === language.code
                          ? 'bg-primary-50 text-primary-700'
                          : 'text-secondary-700 hover:bg-secondary-50'
                      } flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200`}
                    >
                      <span className="mr-2">{language.flag}</span>
                      {language.name}
                    </button>
                  ))}
                </div>
              </div>
              <Link
                to="/"
                className="flex items-center px-3 py-2 rounded-md text-secondary-600 hover:text-primary-700 hover:bg-secondary-50 transition-colors duration-200 text-base font-medium"
              >
                <Home className="mr-2" size={20} />
                {t('nav.home')}
              </Link>
              <Link
                to="/about"
                className="flex items-center px-3 py-2 rounded-md text-secondary-600 hover:text-primary-700 hover:bg-secondary-50 transition-colors duration-200 text-base font-medium"
              >
                <Info className="mr-2" size={20} />
                {t('nav.about')}
              </Link>
              <Link
                to="/contact"
                className="flex items-center px-3 py-2 rounded-md text-secondary-600 hover:text-primary-700 hover:bg-secondary-50 transition-colors duration-200 text-base font-medium"
              >
                <Mail className="mr-2" size={20} />
                {t('nav.contact')}
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-secondary-900 text-white mt-12 sm:mt-16">
        <div className="max-w-7xl mx-auto">
          {/* Upper Footer */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
            {/* About Section */}
            <div className="space-y-6">
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 text-primary-400" />
                <span className="text-2xl font-heading font-bold text-white ml-2">My Blog</span>
              </div>
              <p className="text-secondary-300 leading-relaxed">
                {t('footer.about.description')}
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-lg font-heading font-bold text-white mb-6 flex items-center">
                <Globe className="mr-2 text-primary-400" size={20} />
                {t('footer.quickLinks.title')}
              </h3>
              <ul className="space-y-3">
                <li>
                  <Link to="/" className="text-secondary-300 hover:text-white transition-colors duration-200 flex items-center group">
                    <span className="w-1.5 h-1.5 bg-primary-400 rounded-full mr-2 group-hover:bg-primary-300 transition-colors duration-200"></span>
                    {t('footer.quickLinks.home')}
                  </Link>
                </li>
                <li>
                  <Link to="/about" className="text-secondary-300 hover:text-white transition-colors duration-200 flex items-center group">
                    <span className="w-1.5 h-1.5 bg-primary-400 rounded-full mr-2 group-hover:bg-primary-300 transition-colors duration-200"></span>
                    {t('footer.quickLinks.about')}
                  </Link>
                </li>
                <li>
                  <Link to="/contact" className="text-secondary-300 hover:text-white transition-colors duration-200 flex items-center group">
                    <span className="w-1.5 h-1.5 bg-primary-400 rounded-full mr-2 group-hover:bg-primary-300 transition-colors duration-200"></span>
                    {t('footer.quickLinks.contact')}
                  </Link>
                </li>
                <li>
                  <Link to="/privacy" className="text-secondary-300 hover:text-white transition-colors duration-200 flex items-center group">
                    <span className="w-1.5 h-1.5 bg-primary-400 rounded-full mr-2 group-hover:bg-primary-300 transition-colors duration-200"></span>
                    {t('footer.quickLinks.privacy')}
                  </Link>
                </li>
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h3 className="text-lg font-heading font-bold text-white mb-6 flex items-center">
                <Phone className="mr-2 text-primary-400" size={20} />
                {t('footer.contact.title')}
              </h3>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <Mail className="text-primary-400 mt-1 mr-3" size={18} />
                  <div>
                    <p className="text-white font-medium">{t('footer.contact.email')}</p>
                    <a href="mailto:info@example.com" className="text-secondary-300 hover:text-white transition-colors duration-200">
                      info@example.com
                    </a>
                  </div>
                </li>
                <li className="flex items-start">
                  <Phone className="text-primary-400 mt-1 mr-3" size={18} />
                  <div>
                    <p className="text-white font-medium">{t('footer.contact.phone')}</p>
                    <a href="tel:+1234567890" className="text-secondary-300 hover:text-white transition-colors duration-200">
                      +1 (234) 567-890
                    </a>
                  </div>
                </li>
                <li className="flex items-start">
                  <MapPin className="text-primary-400 mt-1 mr-3" size={18} />
                  <div>
                    <p className="text-white font-medium">{t('footer.contact.address')}</p>
                    <p className="text-secondary-300">
                      123 Blog Street<br />
                      Content City, ST 12345
                    </p>
                  </div>
                </li>
              </ul>
            </div>

            {/* Newsletter */}
            <div>
              <h3 className="text-lg font-heading font-bold text-white mb-6 flex items-center">
                <Mail className="mr-2 text-primary-400" size={20} />
                {t('footer.newsletter.title')}
              </h3>
              <p className="text-secondary-300 mb-4">
                {t('footer.newsletter.description')}
              </p>
              <form className="space-y-3">
                <input
                  type="email"
                  placeholder={t('footer.newsletter.placeholder')}
                  className="w-full px-4 py-2.5 bg-secondary-800 border border-secondary-700 rounded-lg text-white placeholder-secondary-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-colors duration-200"
                />
                <button
                  type="submit"
                  className="w-full px-4 py-2.5 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors duration-200 flex items-center justify-center"
                >
                  <Mail size={18} className="mr-2" />
                  {t('footer.newsletter.button')}
                </button>
              </form>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-secondary-800">
            <div className="px-4 sm:px-6 lg:px-8 py-6">
              <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
                <p className="text-secondary-400 text-sm">
                  {t('footer.copyright')}
                </p>
                <div className="flex items-center space-x-6">
                  <Link to="/privacy" className="text-secondary-400 hover:text-white text-sm transition-colors duration-200">
                    {t('footer.links.privacy')}
                  </Link>
                  <Link to="/terms" className="text-secondary-400 hover:text-white text-sm transition-colors duration-200">
                    {t('footer.links.terms')}
                  </Link>
                  <Link to="/sitemap" className="text-secondary-400 hover:text-white text-sm transition-colors duration-200">
                    {t('footer.links.sitemap')}
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}